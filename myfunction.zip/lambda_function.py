import json
import os

def lambda_handler(event, context):
    
    imgPath = "/var/task/captcha.svl"
    cmd = f"export TESSDATA_PREFIX=$(pwd)/tessdata && ./tesseract {imgPath} stdout --psm 10 --oem 3 -c tessedit_char_whitelist=1234567890"
    captchatext = os.popen(cmd).read()

    return {
        'statusCode': 200,
        'body': captchatext.strip()
    }